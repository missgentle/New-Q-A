import React, { useState, useEffect, useRef } from 'react'
import logo from './logo.svg'
import { Button } from 'antd'
import 'antd/dist/antd.css'
import './App.css'

import { CKEditor } from '@ckeditor/ckeditor5-react'
import ClassicEditor from '@ckeditor/ckeditor5-build-classic'
import viewToPlainText from '@ckeditor/ckeditor5-clipboard/src/utils/viewtoplaintext'
import '@ckeditor/ckeditor5-build-classic/build/translations/zh-cn.js'

import { Editor, Toolbar } from '@wangeditor/editor-for-react'
import '@wangeditor/editor/dist/css/style.css'

import TinymceRichtext from './components/my_tinymce'
import DraftRichtextTS from './components/my_draft'
import DraftRichtext from './components/my-draft'
// import BEDraftRichtext from './components/my_draft_BE'
// import BEDraftRichtext from './components/my-draft-be'
import BEDraftRichtext from './components/AppEditor_BE'


const InitData = '<p>ok!</p><p>&nbsp;</p><p><strong>你好！</strong></p>'
const CK5Config = {
  placeholder: '请输入内容',
  language: 'zh-cn',
  toolbar: [
    'heading',
    '|',
    'bold',
    'italic',
    'link',
    'bulletedList',
    'numberedList',
    '|',
    'uploadImage',
    'undo',
    'redo',
    '|',
    'blockQuote',
    'insertTable',
  ],
  link: { addTargetToExternalLinks: true }, // 超链接在新窗口打开
}

function App() {
  const [contentHtml, setContentHtml] = useState('')
  const [contentText, setContentText] = useState('')

  const [ckEditor, setCkEditor] = useState(null)  // 存储 editor 实例
  const getCK5Data = () => {
    setContentHtml(ckEditor.getData())
    setContentText(viewToPlainText(ckEditor?.editing?.view?.document?.getRoot()))
  }

  const [wangEditor, setWangEditor] = useState(null)
  const toolbarConfig = {} // 菜单栏配置
  // 编辑器配置
  const editorConfig = {
    placeholder: '请输入内容...',
    onCreated: (editor) => {
      console.log(editor)
      setWangEditor(editor)
    },
  }
  const handleGetWangEditorData = () => {
    setContentHtml(wangEditor?.getHtml())
    setContentText(wangEditor?.getText())
  }

  //富文本内容
  const [content, setContent] = useState('')
  const handleEditorTextChange = (text) => {
    setContent(text)
  }
  const handleImageUpload = async (blobInfo, success, failure) => {
    // const response = await getUpPic({ img_type: "testUp", img_byte: "data:image/jpeg;base64," + blobInfo.base64() });
    // if (response && response instanceof Object) {
    //   success(response.data)
    // } else {
    //   failure('上传失败')
    // }
  }
  const handleGetTinymceData = () => {
    setContentHtml(content)
  }

  const draftRichtext = useRef()
  const draftBERichtext = useRef()

  const handleGetDraftData = () => {
    console.log(draftRichtext.current.getDetail())
  }

  const handleGetBEDraftData = () => {
    console.log(draftBERichtext.current.handleSubmitContent())
  }

  return (
    <div className="app">
      <div className="app-left">
        <div className="title">
          <img src={logo} className="react-logo" alt="logo" />
          <a
            className="link"
            href="https://ckeditor.com/ckeditor-5"
            target="_blank"
            rel="noopener noreferrer"
          >
            CKEditor5
          </a>
          <Button className="title-btn" type="primary" onClick={getCK5Data}>获取</Button>
        </div>
        <div className="editor-container">
          <CKEditor
            editor={ClassicEditor}
            data={InitData}
            onReady={editor => {
              // editor.isReadOnly = true
              setCkEditor(editor)
            }}
            config={CK5Config}
          />
        </div>
        <div className="title">
          <img src={logo} className="react-logo" alt="logo" />
          <a
            className="link"
            href="https://www.wangeditor.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            wangEditor
          </a>
          <Button className="title-btn" type="primary" onClick={handleGetWangEditorData}>获取</Button>
        </div>
        <div className="editor-container">
          <div style={{ border: '1px solid #ccc' }}>
            <Toolbar
              editor={wangEditor}
              defaultConfig={toolbarConfig}
              style={{ borderBottom: '1px solid #ccc' }}
            />
            <Editor
              defaultConfig={editorConfig}
              defaultContent={[]}
              style={{ height: '200px' }}
            />
          </div>
        </div>
        <div className="title">
          <img src={logo} className="react-logo" alt="logo" />
          <a
            className="link"
            href="https://www.tiny.cloud"
            target="_blank"
            rel="noopener noreferrer"
          >
            Tinymce
          </a>
          <Button className="title-btn" type="primary" onClick={handleGetTinymceData}>获取</Button>
        </div>
        <div className="editor-container">
          <TinymceRichtext editorHtml={InitData}
            handleEditorTextChange={handleEditorTextChange}
            handleImageUpload={handleImageUpload} />
        </div>
      </div>

      <div className="app-center">
        <div>获取纯文本：</div>
        <div className="data-container">{contentText}</div>
        <div>获取富文本：</div>
        <div className="data-container">{contentHtml}</div>
        <div>还原展示：</div>
        <div
          className="ck5-data-container ck-content data-container"
          dangerouslySetInnerHTML={{ __html: contentHtml || '' }}
        ></div>
      </div>

      <div className="app-right">
        <div className="title">
          <img src={logo} className="react-logo" alt="logo" />
          <a
            className="link"
            href="https://draftjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Draft.js
          </a>
          <Button className="title-btn" type="primary" onClick={handleGetDraftData}>获取</Button>
        </div>
        <div className="editor-container">
          <DraftRichtext ref={draftRichtext} detail={InitData} ></DraftRichtext>
          {/* <DraftRichtextTS detail={InitData} /> */}
        </div>
        <div className="title">
          <img src={logo} className="react-logo" alt="logo" />
          <a
            className="link"
            href="https://www.worldlink.com.cn/en/osdir/braft-editor.html"
            target="_blank"
            rel="noopener noreferrer"
          >
            Braft Editor
          </a>
          <Button className="title-btn" type="primary" onClick={handleGetBEDraftData}>获取</Button>
        </div>
        <div className="editor-container">
          <BEDraftRichtext ref={draftBERichtext} detail={InitData} />
        </div>
      </div>

    </div>
  )
}

export default App;

