
import React, { useState } from 'react'
import BraftEditor from 'braft-editor'
import 'braft-editor/dist/index.css'

const RichtextEdit = (props) => {
  // 设置编辑器初始内容
  const [editorState, setEditorState] = useState(BraftEditor.createEditorState('<p></p>'))
  
  // 编辑内容触发
  const handleChange = (editorState) => {
    setEditorState(editorState)
  }

  // 获取 编辑器内容
  const gettEditorCon = () => {
    const content = editorState.toHTML();
  }
  
  return (
    <div>
       <BraftEditor
          excludeControls={['media']}
          contentStyle={{ height: 305 }}
          value={editorState}
          onChange={handleChange} />
    </div>
  )
}

export default RichtextEdit