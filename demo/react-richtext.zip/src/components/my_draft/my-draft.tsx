import React, { useState, useEffect } from 'react'
import { Editor } from 'react-draft-wysiwyg'
import { EditorState, convertToRaw, ContentState } from 'draft-js'
// import DOMPurify from 'dompurify' //xss净化
import draftToHtml from 'draftjs-to-html'
import htmlToDraft from 'html-to-draftjs'
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css'

const NoteEditor = (props) => {
    const { detail = '' } = props
    const [editorState, setEditorState] = useState(() => EditorState.createEmpty())

    useEffect(() => {
        if (detail) {
            // 如果有值, 根据html格式字符串创建一个对应的编辑对象
            const contentBlock = htmlToDraft(detail)
            if (contentBlock) {
                const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks)
                setEditorState(EditorState.createWithContent(contentState))
            } else {
                setEditorState(EditorState.createEmpty())// 创建一个没有内容的编辑对象
            }
        }
    }, [])

    // 富文本中的图片上传
    const uploadImageCallBack = (file) => {
        return new Promise(
            (resolve, reject) => {
                const xhr = new XMLHttpRequest()
                xhr.open('POST', '/manage/img/upload')
                const data = new FormData()
                data.append('image', file)
                xhr.send(data)
                xhr.addEventListener('load', () => {
                    const response = JSON.parse(xhr.responseText)
                    const url = response.data.url // 得到图片的url
                    resolve({ data: { link: url } })
                })
                xhr.addEventListener('error', () => {
                    const error = JSON.parse(xhr.responseText)
                    reject(error)
                })
            }
        )
    }

    // 返回输入数据对应的html格式的文本
    const handleGetDraftDataTS = () => {
        console.log(draftToHtml(convertToRaw(editorState?.getCurrentContent())))
        console.log(editorState?.getCurrentContent()?.getPlainText())
    }

    // const createMarkup = (html) => {
    //     return html
    //     // return  {
    //     //   __html: DOMPurify.sanitize(html)
    //     // }
    // }

    return (
        <div>
            <Editor
                editorState={editorState}
                editorStyle={{ border: "1px solid #000", minHeight: "200px", padding: "0 10px" }}
                //绑定监听，在内容change的时候调用
                onEditorStateChange={editorState => {
                    setEditorState(editorState)
                }}
                toolbar={{
                    image: {
                        uploadCallback: uploadImageCallBack,
                        alt: { present: true, mandatory: true }
                    },
                }}
            />
            <button onClick={handleGetDraftDataTS}>获取</button>
        </div>
    )
};

export default NoteEditor