import React, { Component } from "react";
// 添加ie10支持
import "braft-polyfill";
import BraftEditor from "braft-editor";
import "braft-editor/dist/index.css";
import PropTypes from "prop-types";
// import axios from "axios";
// import { message } from "antd";


import "./style.less"; // 见下文
import config from "./config"; // 见下文
import mediaBaseconfig from "./media"; // 见下文
// import {
//   uploadHtml,
//   uploadImage,
//   maxFileSize,
//   isImageFile
// } from "@/utils/upload"; // 见下文 uploadHtml和uploadImage是定义的上传文件到后端的接口，根据自己的项目更换


class AppEditor extends Component {
  static propTypes = {
    detail: PropTypes.string, // 富文本初始内容
    fileMaxSize: PropTypes.number //  限制图片文件大小
  }

  state = {
    // 创建一个空的editorState作为初始值
    editorState: BraftEditor.createEditorState(null)
  }

  // 默认的props
  static defaultProps = {
    detail: '',
    fileMaxSize: 2 // 单位默认是Mb,
  }

  // constructor(props) {
  //   super(props)
  // }

  // //初始化编辑器内容
  async componentWillReceiveProps(props) {
    try {
      const { detail } = props
      console.log(detail)
      // const { data } = await axios.get(detail)
      // this.setState({
      //   editorState: BraftEditor.createEditorState(data)
      // })
      // return data
      this.setState({
        editorState: BraftEditor.createEditorState(detail)
      })
      return detail
    } catch (error) {
      console.log(error)
    }
  }

  // componentDidMount() {
  //   this.setState({
  //     editorState: BraftEditor.createEditorState(this.props.detail ? this.props.detail : '<p>123</p>')
  //   })
  // }

  // componentDidMount() {
  //   const html = this.props.detail
  //   if (html) {
  //     this.setState({
  //       editorState: BraftEditor.createEditorState(html)
  //     })
  //     return html
  //   }
  // }

  componentWillUnmount() {
    this.setState = (state, callback) => {
      return
    }
  }

  // 子组件上传方法（供父组件调用）
  handleSubmitContent = async () => {
    const htmlContent = this.state.editorState.toHTML()
    console.log(htmlContent)
    // try {
    //   const url = await uploadHtml(htmlContent);
    //   return url;
    // } catch (error) {
    //   console.log(error);
    // }
  };

  // 监听编辑器内容变化同步内容到state
  handleEditorChange = editorState => {
    this.setState({ editorState })
  }

  // 媒体上传校验
  mediaValidate = file => {
    const { fileMaxSize } = this.props

    // // 类型限制
    // if (!isImageFile(file)) {
    //   return false;
    // }

    // // 大小限制
    // if (fileMaxSize && !maxFileSize(file, fileMaxSize)) {
    //   return false;
    // }

    return true
  }

  // 媒体上传
  mediaUpload = async ({ file, success, error }) => {
    // message.destroy();
    // try {
    //   const url = await uploadImage(file);
    //   success({ url });
    //   message.success("上传成功");
    // } catch (err) {
    //   error(err);
    //   message.error(err.message || "上传失败");
    // }
  };

  render() {
    const { editorState } = this.state

    // 媒体配置
    const media = {
      // 上传校验
      validateFn: this.mediaValidate,
      // 上传
      uploadFn: this.mediaUpload,
      // 基本配置
      ...mediaBaseconfig
    }

    return (
      <div
        className="custom-editor"
        style={{ marginTop: 20, ...this.props.style }}
      >
        <BraftEditor
          style={{ height: 400, overflow: "hidden" }}
          {...config}
          media={media}
          value={editorState}
          onChange={this.handleEditorChange}
        />
      </div>
    )
  }
}

export default AppEditor



